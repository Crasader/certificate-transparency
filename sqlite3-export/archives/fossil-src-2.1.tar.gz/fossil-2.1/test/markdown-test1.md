
Markdown Formatter Test Document
================================

This document is designed to test the markdown formatter.

 * A bullet item.
     *  A subitem
 * Second bullet

More text

 1. Enumeration
    1.1.  Subitem 1
    1.2.  Subitem 2
 2. Second enumeration.

Another paragraph.



Other Features
--------------

Text can show *emphasis* or _emphasis_ or **strong emphassis**.
