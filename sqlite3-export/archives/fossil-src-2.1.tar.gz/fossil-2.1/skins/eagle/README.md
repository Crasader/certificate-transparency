For this skin to look exactly as it was intended to, the **white-foreground**
setting should be enabled.

This skin was contributed by Joe Mistachkin.
