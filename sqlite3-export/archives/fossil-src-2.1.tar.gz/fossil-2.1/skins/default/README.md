This skin was contributed by Étienne Deparis.

On 2015-03-14 this skin was promoted from an option to the default, which
involved moving it from its original home in the skins/etienne1 directory
into skins/default.
